import numpy as np
from metrics import align_inverse_depth, depth_metrics
d = np.load("example.npz")
aligned, fit = align_inverse_depth(d["inverse_depth"], d["ground_truth_m"], d["valid_mask"])
print(fit)
print(depth_metrics(aligned, d["ground_truth_m"], d["valid_mask"]))
