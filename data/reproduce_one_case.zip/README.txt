Recompute one NYU example from real saved arrays
=================================================
This is native Depth Anything V2 Small, NYU zero-based record 0.
Expected oracle-aligned AbsRel: 0.026053547429939143.
Reference: https://cs.nyu.edu/~fergus/datasets/nyu_depth_v2.html
The original RGB image is not needed to recompute the score.

Install numpy, then run: python recompute.py
The alignment uses the same pixels that are scored: this is an oracle
shape-agreement exercise, not deployable metric calibration.
The mask is sensor-supported and cropped. See metrics.py for the protocol.
Model/checkpoint/source pins and the complete experiment are in provenance.json.
